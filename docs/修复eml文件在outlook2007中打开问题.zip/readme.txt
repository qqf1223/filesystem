These registry keys support the article;
http://www.msoutlook.info/question/354

If you downloaded this file from any other location, please visit the
above page to download a fresh copy as it is the only way I can assure
you that you've downloaded a malware free version.

Before importing any of the registry keys, make a backup of the
following registry key just in case you want to easily restore your
eml-file registration back to your current eml-handler;
HKEY_CLASSES_ROOT\.eml

Best regards and enjoy!
Robert Sparnaaij aka Roady